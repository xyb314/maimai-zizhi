function calc(start, mode)
    x1 = start:25/73/8:start+25/73;
    y1 = 4.149514667*(x1-start).*(x1-start-25/73)+start+50/73;
    x2 = start+25/73:25/73/8:start+50/73;
    y2 = 4.149514667*(x2-start-50/73).*(x2-start-25/73)+start+50/73;
    k1 = zeros(1,8);
    k2 = k1;
    b1 = k1;
    b2 = k1;
    for i = 1:8
        k1(i) = (y1(i+1)-y1(i))/(x1(i+1)-x1(i));
        b1(i) = y1(i)-x1(i)*(y1(i+1)-y1(i))/(x1(i+1)-x1(i));
        k2(i) = (y2(i+1)-y2(i))/(x2(i+1)-x2(i));
        b2(i) = y2(i)-x2(i)*(y2(i+1)-y2(i))/(x2(i+1)-x2(i));
    end
    fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, 1.0000\n', x1(1)-1, mode*2);
    fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, 0.6849\n', x1(1)-1, mode*2+1);
    for i = 1:8
        fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, %.4f,\n', x1(i), mode*2, k1(i));
        fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, %.4f,\n', x1(i), mode*2+1, b1(i));
    end
    for i = 1:8
        fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, %.4f,\n', x2(i), mode*2, k2(i));
        fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, %.4f,\n', x2(i), mode*2+1, b2(i));
    end
    fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, 1.0000\n', x2(9), mode*2);
    fprintf('0.0000, 0.0000, %.4f, -1,  0,  0,  0,  %d, 0.0000\n', x2(9), mode*2+1);
end